<?php

interface FormInterface
{
    /**
     * Define a custom form validation interface.
     *
     * @return void
     */

    public function filterForm(): void;
}
